//
//  PropertyChangesViewController.swift
//  Animation
//
//  Created by Quang Tran on 1/26/19.
//  Copyright © 2019 Quang Tran. All rights reserved.
//

import UIKit

class PropertyChangesViewController: UIViewController {

    @IBOutlet weak var movingView: UIView!
    @IBOutlet weak var rotatingView: UIView!
    @IBOutlet weak var scalingView: UIView!
    @IBOutlet weak var alphaView: UIView!
    @IBOutlet weak var backgroundColorView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    @IBAction func moveView(_ sender: Any) {
        
    }

    @IBAction func rotateView(_ sender: Any) {
        
    }
    
    @IBAction func scaleView(_ sender: Any) {
        
    }
    
    @IBAction func changeAlpha(_ sender: Any) {
        
    }
    
    @IBAction func changeBackgroundColor(_ sender: Any) {
        
    }
}
