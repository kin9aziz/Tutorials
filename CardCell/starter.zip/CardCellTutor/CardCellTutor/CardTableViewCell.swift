//
//  CardTableViewCell.swift
//  CardCell
//
//  Created by Quang Tran on 1/22/19.
//  Copyright © 2019 Quang Tran. All rights reserved.
//

import UIKit

class CardTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
}
